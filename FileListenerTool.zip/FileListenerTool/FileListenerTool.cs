﻿/*
 * Copyright Microsoft Corp. 2019.
 * 
 * Troubleshooting utility to detect log file changes using the same
 * mechanism that OMS solution for custom logs and IIS logs use.
 * 
 * Use this to troubleshoot incidents related to delayed/missing custom/IIS
 * logs.
 * 
 * For example, some apps do not flush the content to filesystem and
 * internally buffer it. In such cases no notifications are received
 * by the OMS solutions and customer observes delayed upload.
 * 
 */

using System;
using System.IO;
using System.Security.Permissions;
namespace FileListenerTool
{
    public class FileListenerTool
    {
        public static void Main()
        {
            Run();
        }

        [PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
        public static void Run()
        {
            string[] args = System.Environment.GetCommandLineArgs();

            if (args.Length != 3 || !Directory.Exists(args[1]) || string.IsNullOrEmpty(args[2]))
            {
                Console.WriteLine("Usage: FileListenerTool.exe [logs directory] [file pattern]");
                Console.WriteLine("For example, FileListenerTool.exe c:\\mylogs *.log");
                return;
            }

            string dir = args[1];
            string fileFilter = args[2];
            Console.WriteLine("Tracking changes to {0} in directory {1}", fileFilter, dir);

            FileSystemWatcher watcher = new FileSystemWatcher
            {
                Path = dir,
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size,
                Filter = fileFilter
            };
            watcher.Changed += OnChanged;
            watcher.Error += OnError;
            watcher.EnableRaisingEvents = true;
            Console.WriteLine("Type \'q\' to quit.");
            while (Console.Read() != 'q') { }
        }

        private static void OnChanged(object source, FileSystemEventArgs e)
        {
            Console.WriteLine("[{0}] {1} {2}", DateTime.UtcNow, e.FullPath, e.ChangeType);
        }

        private static void OnError(object source, ErrorEventArgs e)
        {
            Console.WriteLine("Error: [{0}] {1}", DateTime.UtcNow, e.ToString());
        }
    }
}